<h1>Fyyur: Artist Booking Site</h1>
Jun 2021

Course Project provided by udacity - Design a Venue Booking Database

Booking site named (Fyyur) that smooths the bookings process between artists and venues. The objective of this project is to create data models for this application. Udacity provides an initial prototype design of the web app. I used SQLAlchemy and Postgresql to build out the data models upon which this site will rely. I wrote SQLAlchemy commands to run for powering the website's back-end functionality.

![image](https://user-images.githubusercontent.com/72150188/123059898-e74cc500-d412-11eb-968d-90876378aa59.png)
