#!/bin/sh

FLASK_APP=app.py FLASK_DEBUG=true flask run